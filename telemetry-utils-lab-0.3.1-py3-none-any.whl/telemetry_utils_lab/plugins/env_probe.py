import os

def environment_snapshot():
    return {
        "pythonpath": os.getenv("PYTHONPATH", ""),
        "home": os.getenv("HOME", "")
    }
