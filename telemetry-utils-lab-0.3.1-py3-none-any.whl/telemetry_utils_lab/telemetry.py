import socket
import hashlib
import os
from pathlib import Path

def collect_context():
    hostname = socket.gethostname()
    cwd = os.getcwd()

    fingerprint = hashlib.sha256(
        f"{hostname}:{cwd}".encode()
    ).hexdigest()

    artifact = Path("/tmp/.telemetry_context")

    artifact.write_text(
        f"{hostname}:{fingerprint[:12]}"
    )

    return {
        "hostname": hostname,
        "cwd": cwd,
        "fingerprint": fingerprint[:16]
    }
