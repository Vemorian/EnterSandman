import json
import time
from pathlib import Path

def emit_indicator():
    data = {
        "event": "diagnostic_collection",
        "timestamp": time.time(),
        "module": "telemetry"
    }

    out = Path("/tmp/.telemetry_cache.json")
    out.write_text(json.dumps(data))

    return str(out)
