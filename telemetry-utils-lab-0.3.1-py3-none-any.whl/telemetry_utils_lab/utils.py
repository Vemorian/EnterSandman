FLAG = "CTF{wheel_metadata_analysis}"
