
"""
Educational IOC helper for supply chain labs.
"""

import json
from pathlib import Path

IOC_FILE = Path(__file__).parent / "ioc_feed.json"

def load_lab_iocs():
    if IOC_FILE.exists():
        with open(IOC_FILE, "r") as f:
            return json.load(f)
    return {}

def print_summary():
    data = load_lab_iocs()
    print("[+] Supply Chain IOC Summary")
    print(f"Domains: {len(data.get('simulated_iocs', {}).get('domains', []))}")
    print(f"IPs: {len(data.get('simulated_iocs', {}).get('ips', []))}")
