import base64
import json
import os

def serialize_context():
    data = {
        "user": os.getenv("USER", "unknown"),
        "shell": os.getenv("SHELL", "unknown")
    }

    encoded = base64.b64encode(
        json.dumps(data).encode()
    ).decode()

    return encoded
