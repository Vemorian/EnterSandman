import importlib

def load_plugin(name="env_probe"):
    return importlib.import_module(
        f"telemetry_utils_lab.plugins.{name}"
    )
